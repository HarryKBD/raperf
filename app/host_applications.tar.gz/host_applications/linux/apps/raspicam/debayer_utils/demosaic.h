#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <EGL/egl.h>
#include  "bcm_host.h"
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cmath>
//#define USE_OPENCV 1

#define AWB_OFF         0
#define AWB_FIXED       1
#define AWB_GIMP        2
#define AWB_GRAY_WORLD  3
#define AWB_WHITE_PATCH 4
#define AWB_WEIGHTED    5
using namespace std;

#ifdef USE_OPENCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/photo/photo.hpp>
using namespace cv;
#endif

class Demosaic
{
    uint32_t width, height;
    float weightRed, weightGreen, weightBlue;
    float minRed, minGreen, minBlue;
    //float brightnes, contrast;
    EGLNativeWindowType  hWnd;
    EGLDisplay eglDisplay;
    EGLContext eglContext;
    EGLSurface eglSurface;

    // Handle to a program object
    GLuint programObject;
    GLuint programFilter;

    // Attribute locations
    GLint  positionLoc;
    GLint  texCoordLoc;

    GLint  positionLocFilter;
    GLint  texCoordLocFilter;

    // Sampler location
    GLint samplerLoc;
    GLint samplerLocFilter;

    // Texture handle
    GLuint textureId;
    GLuint textureIdFilter;
    GLuint textureAwbVignette;

    //Frame buffer
    GLuint frameBuffer;

    // input to shader
    GLint firstRed;
    GLint sourceSize;

    GLint uBrightness;
    GLint  uContrast;

    GLint uWeightR;
    GLint uWeightG;
    GLint uWeightB;

    GLint uBalanceR;
    GLint uBalanceG;
    GLint uBalanceB;

    GLint uExposure;

    GLint uGamma;

    GLint uHistogramMin;
    GLint uHistogramMax;

    GLint filterRx;
    GLint filterGx;
    GLint filterBx;
    GLint filterRplus;
    GLint filterGplus;
    GLint filterBplus;

    GLint filterRexp;
    GLint filterGexp;
    GLint filterBexp;

    GLint uHminR;
    GLint uHminG;
    GLint uHminB;

    GLint uStep;
    GLint uBitsH;
    GLint uBitsL;
    GLint uBitsM;

    GLboolean esCreateWindow();
    EGLBoolean CreateEGLContext();
    void DestroyEGLContext();
    void initShader();
    void initFullShader();
    void initFilterShader();
    GLuint CreateSimpleTexture2D( );
    GLuint compile_shader(GLenum type, const std::string& filename);
    GLuint link_program(const vector<GLuint>& shaders);

public:
    Demosaic(uint32_t width, uint32_t height, uint32_t brightnes, uint32_t contrast);
    struct DEBAYER_PARAMS {
        DEBAYER_PARAMS(): awb_method(1), denoise_bayer_on(false), denoise_rgb_on(false), sharp_on(false), weight_red(1.33), weight_green(1.0), weight_blue(1.33) {}
        int width;
        int height;
        float brightnes;
        float contrast;
        float weight_red;
        float weight_green;
        float weight_blue;
        float balance_red;
        float balance_green;
        float balance_blue;
        float exposure;
        float gamma;
        float histogramm_min;
        float histogramm_max;
        int   internal_bits_per_channel;
        int   awb_method;
        bool  denoise_bayer_on;
        bool  denoise_rgb_on;
        bool  sharp_on;
    };
    void process(unsigned char * inGray, unsigned char * outRGB);
    void processFullDebayer(unsigned char * inGray, unsigned char * outRGB, DEBAYER_PARAMS params);
    void sensorRGB2sRGBspace(unsigned char* bayer, int width, int len, DEBAYER_PARAMS params);
    void calculateHistogramMap(unsigned char* interpolatedData);
    void awbColorWeights(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params);
    void grayWorld(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params);
    void whitePatch(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params);
    void initColorWeights(unsigned char* rgb, int len);
    void IWB(unsigned char* orig_rgb, int width, long len);
    float k_of_(float x);
    int sign(float x);
    void gimp_awb(unsigned char* rgb, int width, int len, DEBAYER_PARAMS* params);
    int clamp(int color);
    void hist_equalize(unsigned char* rgb, int width, long len);
    //void cumhist(int* , int* );
    void equalizeHistogram(unsigned char * pdata, int width, int height, int max_val);
    void normalizeHistogram(unsigned char* rgb, int width, long len);
    #ifdef USE_OPENCV
    unsigned char* denoiseBayer(unsigned char* input, int len, int width, int height, DEBAYER_PARAMS params);
    Mat filter_single_channel(unsigned char * ch, int w, int h, int type );
    cv::Mat wiener_decon(cv::Mat img);
    cv::Mat get_psf();
    cv::Mat blur_edge(cv::Mat img, int border);
    #endif
    ~Demosaic();
};
