#ifdef __cplusplus
extern "C" {
#endif

void start();
void stop(const char *msg);

#ifdef __cplusplus
}
#endif
