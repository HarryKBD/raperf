#include "demosaic_connector.h"
#include "demosaic.h"

demosaic_t demosaic_init(int width, int height, int brightness, int contrast) {
   return new Demosaic(width, height, brightness, contrast);
}

 void demosaic_destroy(demosaic_t untyped_ptr) {
    Demosaic* typed_ptr = static_cast<Demosaic*>(untyped_ptr);
    delete typed_ptr;
 }

 void demosaic_process(demosaic_t untyped_self, unsigned char * inGray, unsigned char * outRGB) {
    Demosaic* typed_self = static_cast<Demosaic*>(untyped_self);
    typed_self->process(inGray, outRGB);
 }

  void debayer_process(demosaic_t untyped_self, unsigned char * inGray, unsigned char * outRGB, float brightnes, float contrast,
                                  float bR, float bG, float bB, float exp, float gamma, float hMin, float hMax, int ibpch, int awb, bool dnz_bayer, bool dnz_rgb, bool sharp) {
    Demosaic* typed_self = static_cast<Demosaic*>(untyped_self);
    struct Demosaic::DEBAYER_PARAMS params;
    params.brightnes = brightnes;
    params.contrast = contrast;
    params.balance_red = bR;
    params.balance_green = bG;
    params.balance_blue = bG;
    params.exposure = exp;
    params.gamma = gamma;
    params.histogramm_min = hMin;
    params.histogramm_max = hMax;
    params.internal_bits_per_channel = ibpch;
    params.awb_method = awb;
    params.denoise_bayer_on = dnz_bayer;
    params.denoise_rgb_on = dnz_rgb;
    params.sharp_on = sharp;

    typed_self->processFullDebayer(inGray, outRGB,params);
 }
