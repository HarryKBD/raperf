#include "demosaic.h"

#ifdef USE_OPENCV
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/photo/photo.hpp>
using namespace cv;
#endif

using namespace std;

#define DEBUG 0
Demosaic::Demosaic(uint32_t width, uint32_t height, uint32_t brightnes, uint32_t contrast)
{
    this->width = width;
    this->height = height;

    bcm_host_init();
    if(esCreateWindow () == GL_FALSE)
        cout << "failed to create gl window" << endl;
    initFullShader();

}
void Demosaic::process(unsigned char * inGray, unsigned char * outRGB)
{
}
void Demosaic::processFullDebayer(unsigned char * inGray, unsigned char * outRGB, DEBAYER_PARAMS params)
{
    //cout << getBuildInformation()<< endl;
        sensorRGB2sRGBspace(inGray,width,width*height, params);
        if(params.awb_method == AWB_GIMP)
        {
            params.weight_red   = 1;
            params.weight_green = 1;
            params.weight_blue  = 1;
        }
        if(params.awb_method == AWB_GIMP)
            gimp_awb(inGray, width, width*height, &params);
        if(params.awb_method == AWB_GRAY_WORLD)
            grayWorld(inGray, width, width*height, &params);
        if(params.awb_method == AWB_WEIGHTED)
            awbColorWeights(inGray, width, width*height, &params);
        if(params.awb_method == AWB_WHITE_PATCH)
            whitePatch(inGray, width, width*height, &params);
        #ifdef USE_OPENCV
        if(params.denoise_bayer_on)
            inGray = denoiseBayer(inGray, width*height, width, height, params);
        #endif

    //cout << " w:" <<wR<<","<<wG<<","<<wB<<" Bal:"<<bR<<","<<bG<<","<<bG<<"exp gamma br con"<<exp<<","<<gamma<<","<<brightness<<","<<contrast;
    //Calculate filter values
    float factor = ((259.0/255.0) * (params.contrast + 1.0)) / (1.0 * ((259.0/255.0) - params.contrast));
    float fRx = params.contrast;//factor *  pow((pow(2, params.exposure/2)/params.balance_red),1.0f/params.gamma);
    float fGx = factor *  pow((pow(2, params.exposure/2)/params.balance_green),1.0f/params.gamma);
    float fBx = factor *  pow((pow(2, params.exposure/2)/params.balance_blue),1.0f/params.gamma);

    float fRplus = factor * (params.brightnes - 128.0/255.0) + 128.0/255.0;
    float fGplus = factor * (params.brightnes - 128.0/255.0) + 128.0/255.0;
    float fBplus = factor * (params.brightnes - 128.0/255.0) + 128.0/255.0;

    //cout << "Process debayer" << endl;
    GLfloat vVertices[] = { 1.0f, -1.0f, 0.0f,  // Position 2
                            1.0f,  0.0f,        // TexCoord 0
                            1.0f,  1.0f, 0.0f,  // Position 3
                            1.0f,  1.0f,        // TexCoord 1
                           -1.0f,  1.0f, 0.0f,  // Position 0
                            0.0f,  1.0f,        // TexCoord 2
                           -1.0f, -1.0f, 0.0f,  // Position 1
                            0.0f,  0.0f         // TexCoord 3
    };
    GLushort indices[] = { 0, 1, 2, 0, 2, 3 };

    // Set the viewport
    glViewport ( 0, 0, width, height );

    // Clear the color buffer
    glClear ( GL_COLOR_BUFFER_BIT );

    // Use the program object
    glUseProgram ( programObject );

    // Load the vertex position
    glVertexAttribPointer ( positionLoc, 3, GL_FLOAT,
                           GL_FALSE, 5 * sizeof(GLfloat), vVertices );
    // Load the texture coordinate
    glVertexAttribPointer ( texCoordLoc, 2, GL_FLOAT,
                           GL_FALSE, 5 * sizeof(GLfloat), &vVertices[3] );

    glEnableVertexAttribArray ( positionLoc );
    glEnableVertexAttribArray ( texCoordLoc );

    glBindFramebuffer(GL_FRAMEBUFFER, frameBuffer);
    glViewport(0, 0, width, height);

    //cout << "Process debayer: Bind texture" << endl;
    glActiveTexture ( GL_TEXTURE0 );
    glBindTexture ( GL_TEXTURE_2D, textureId );


    //cout << "Load data to GPU" << endl;
    if(params.internal_bits_per_channel == 10)
    {
        if(DEBUG) cout << "Process debayer: 10 bit colors" << endl;
        glUniform1f(uBitsH, 256.0);
        glUniform1f(uBitsL, 1.0);
        glUniform1f(uBitsM, 255.0/65535.0);
        glTexImage2D ( GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA, width, height, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, inGray );
    } else
    {
        if(DEBUG) cout << "Process debayer: 8 bit colors" << endl;
        glTexImage2D ( GL_TEXTURE_2D, 0, GL_LUMINANCE, width, height, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, inGray );
    }
    //cout << "Load data to GPU: done" << endl;
    // Set the sampler texture unit to 0
    glUniform1i ( samplerLoc, 0 );

    glUniform1f(uWeightR, params.weight_red);
    glUniform1f(uWeightG, params.weight_green);
    glUniform1f(uWeightB, params.weight_blue);


    glUniform1f(uHminR, minRed);
    glUniform1f(uHminG, minGreen);
    glUniform1f(uHminB, minBlue);

    glUniform1f(filterRx, fRx);
    glUniform1f(filterGx, fGx);
    glUniform1f(filterBx, fBx);
    glUniform1f(filterRplus, fRplus);
    glUniform1f(filterGplus, fGplus);
    glUniform1f(filterBplus, fBplus);

    glUniform1f(filterRexp, 1.0f/params.gamma);
    glUniform1f(filterGexp, 1.0f/params.gamma);
    glUniform1f(filterBexp, 1.0f/params.gamma);

    glUniform1f(uStep, 1.0f);

    //cout << "Process debayer: Draw" << endl;
    glDrawElements ( GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, indices );
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glBindRenderbuffer(GL_RENDERBUFFER, 0);
    glClearColor ( 0.0f, 0.0f, 0.0f, 1.0f );

    //glActiveTexture ( GL_TEXTURE1 );
    glBindTexture ( GL_TEXTURE_2D, textureAwbVignette);
    //glTexImage2D ( GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, 0 );
    glUniform1f(uStep, 2.0f);
    //glUniform1i ( samplerLoc, 1 );

    glDrawElements ( GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, indices );

    //cout << "Process debayer: Read pixels" << endl;
    glReadPixels(0,0, width, height, GL_RGB, GL_UNSIGNED_BYTE, outRGB);

    //*
    #ifdef USE_OPENCV
    if(params.denoise_rgb_on)
    {
        Mat img(height, width, CV_8UC3, outRGB, 0);
        Mat img_filtered(height, width, CV_8UC3);
        Mat rr, gg, bb;


        //fastNlMeansDenoisingColored(img, img_filtered, 2.0, 2.0, 3, 11);
        bilateralFilter(img, img_filtered, 3, 75, 75, BORDER_REFLECT);
        memcpy(outRGB, img_filtered.data, height*width*3);

        //DEconv
        /*Mat R, G, B;
        vector<Mat> channels(3);
        vector<Mat> out_channels;
        split(img, channels);
        R = channels[2];
        G = channels[1];
        B = channels[0];

        rr = wiener_decon(R);
        gg = wiener_decon(G);
        bb = wiener_decon(B);

        out_channels.push_back(rr);
        out_channels.push_back(gg);
        out_channels.push_back(bb);

        merge(out_channels, img_filtered);
        Mat zero = Mat::zeros(img.size(),CV_8UC3);

        cout<<"Zero:"<<zero.size() << " d:"<<zero.channels()<<" t:"<<zero.depth()<<endl;
        cout<<"Filt:"<<img_filtered.size() << " d:"<<img_filtered.channels()<<" t:"<<img_filtered.depth()<<endl;
        cout<<"RGB"<<endl;
        //unsigned char * ptrRGB = &outRGB;
        memcpy(outRGB, img_filtered.data, height*width*3);
        //*ptrRGB = zero.data;//0;//img_filtered.data; //TODO: !!! CHECK FOR MEMORY LEAKS!!!
        */

    }
    if(params.sharp_on)
    {
        Mat frame(height, width, CV_8UC3, outRGB, 0);
        Mat image(height, width, CV_8UC3);
        GaussianBlur(frame, image, cv::Size(0, 0), 3);
        addWeighted(frame, 1.5, image, -0.5, 0, image);
        memcpy(outRGB, image.data, height*width*3);
    }
    #endif

    //cout << "I've got the data!"<<endl;
    //IWB(outRGB, width, width*height*3);
  //  gimp_awb(outRGB, width, width*height*3);
    //normalizeHistogram(outRGB, width, width*height*3);
    /*long len = width*height*3;
    unsigned char *r_ch = (unsigned char *)malloc(len/3);
    unsigned char *g_ch = (unsigned char *)malloc(len/3);
    unsigned char *b_ch = (unsigned char *)malloc(len/3);
    long i = 0;
    long j = 0;
    for(i = 0; i < len; i +=3)
    {
        r_ch[j]=outRGB[i];
        g_ch[j]=outRGB[i+1];
        b_ch[j]=outRGB[i+2];
        j++;
    }
    equalizeHistogram(r_ch, width, height, 255);
    equalizeHistogram(g_ch, width, height, 255);
    equalizeHistogram(b_ch, width, height, 255);
    j = 0;
    for(i = 0; i < len; i +=3)
    {
        outRGB[i]  =r_ch[j];
        outRGB[i+1]=g_ch[j];
        outRGB[i+2]=b_ch[j];
        j++;
    }
    free(r_ch);
    free(g_ch);
    free(b_ch);*/
    //hist_equalize(outRGB, width, width*height*3);

    //cout << "Process Done: Code:" << glGetError() << endl;
}

Demosaic::~Demosaic()
{
    // Delete texture object
    glDeleteTextures ( 1, &textureId );
    glDeleteTextures ( 1, &textureIdFilter );

    // Delete program object
    glDeleteProgram ( programObject );
    glDeleteProgram ( programFilter );

    //Destroy EGL context
    DestroyEGLContext();
}

GLboolean Demosaic::esCreateWindow ()
{
    static EGL_DISPMANX_WINDOW_T nativewindow;
    DISPMANX_DISPLAY_HANDLE_T dispman_display;
    DISPMANX_UPDATE_HANDLE_T dispman_update;
    VC_RECT_T dst_rect;
    VC_RECT_T src_rect;

    uint32_t display_width;
    uint32_t display_height;

    // create an EGL window surface, passing context width/height
    if ( graphics_get_display_size(0 /* LCD */, &display_width, &display_height) < 0 )
    {
        return GL_FALSE;
    }

    display_width = this->width;
    display_height = this->height;

    dst_rect.x = 0;
    dst_rect.y = 0;
    dst_rect.width = this->width;
    dst_rect.height = this->height;

    src_rect.x = 0;
    src_rect.y = 0;
    src_rect.width = this->width << 16;
    src_rect.height = this->height << 16;

    dispman_display = vc_dispmanx_display_open( 0 /* LCD */);
    dispman_update = vc_dispmanx_update_start( 0 );

    nativewindow.element = vc_dispmanx_element_add ( dispman_update, dispman_display,
              0/*layer*/, &dst_rect, 0/*src*/,
              &src_rect, DISPMANX_PROTECTION_NONE, 0 /*alpha*/, 0/*clamp*/, DISPMANX_NO_ROTATE/*transform*/);;
    nativewindow.width = this->width;
    nativewindow.height = this->height;

    vc_dispmanx_update_submit_sync( dispman_update );

    this->hWnd = &nativewindow;

    if ( !CreateEGLContext() )
    {
        return GL_FALSE;
    }


    return GL_TRUE;
}

/// esCreateWindow flag - RGB color buffer
#define ES_WINDOW_RGB           0
/// esCreateWindow flag - ALPHA color buffer
#define ES_WINDOW_ALPHA         1
/// esCreateWindow flag - depth buffer
#define ES_WINDOW_DEPTH         2
/// esCreateWindow flag - stencil buffer
#define ES_WINDOW_STENCIL       4
/// esCreateWindow flat - multi-sample buffer
#define ES_WINDOW_MULTISAMPLE   8

EGLBoolean Demosaic::CreateEGLContext ()
{
   EGLint numConfigs;
   EGLint majorVersion;
   EGLint minorVersion;
   EGLConfig config;

   EGLint attribList[] =
   {
       EGL_RED_SIZE,       5,
       EGL_GREEN_SIZE,     6,
       EGL_BLUE_SIZE,      5,
       EGL_ALPHA_SIZE,     (ES_WINDOW_RGB & ES_WINDOW_ALPHA) ? 8 : EGL_DONT_CARE,
       EGL_DEPTH_SIZE,     (ES_WINDOW_RGB & ES_WINDOW_DEPTH) ? 8 : EGL_DONT_CARE,
       EGL_STENCIL_SIZE,   (ES_WINDOW_RGB & ES_WINDOW_STENCIL) ? 8 : EGL_DONT_CARE,
       EGL_SAMPLE_BUFFERS, (ES_WINDOW_RGB & ES_WINDOW_MULTISAMPLE) ? 1 : 0,
       EGL_NONE
   };

   EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };


   // Get Display
   this->eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
   if ( this->eglDisplay == EGL_NO_DISPLAY )
   {
      return EGL_FALSE;
   }

   // Initialize EGL
   if ( !eglInitialize(this->eglDisplay, &majorVersion, &minorVersion) )
   {
      return EGL_FALSE;
   }

   // Get configs
   if ( !eglGetConfigs(this->eglDisplay, NULL, 0, &numConfigs) )
   {
      return EGL_FALSE;
   }

   // Choose config
   if ( !eglChooseConfig(this->eglDisplay, attribList, &config, 1, &numConfigs) )
   {
      return EGL_FALSE;
   }

   // Create a surface
   this->eglSurface = eglCreateWindowSurface(this->eglDisplay, config, this->hWnd, NULL);
   if ( this->eglSurface == EGL_NO_SURFACE )
   {
      return EGL_FALSE;
   }

   // Create a GL context
   this->eglContext = eglCreateContext(this->eglDisplay, config, EGL_NO_CONTEXT, contextAttribs );
   if ( this->eglContext == EGL_NO_CONTEXT )
   {
      return EGL_FALSE;
   }

   // Make the context current
   if ( !eglMakeCurrent(this->eglDisplay, this->eglSurface, this->eglSurface, this->eglContext) )
   {
      return EGL_FALSE;
   }

   return EGL_TRUE;
}

void Demosaic::DestroyEGLContext (){
    eglDestroyContext(this->eglDisplay,this->eglContext );
    eglDestroySurface(this->eglDisplay, this->eglSurface);
    eglTerminate(this->eglDisplay);
}
#ifdef USE_OPENCV
unsigned char* Demosaic::denoiseBayer(unsigned char* input, int len, int width, int height, DEBAYER_PARAMS params){

    unsigned char * gCh = (unsigned char *)malloc(len/2);
    unsigned char * rCh = (unsigned char *)malloc(len/4);
    unsigned char * bCh = (unsigned char *)malloc(len/4);
    bool redLine = true;
    int i =0;
    int c = 0;
    int step = 1;
    int r_counter, g_counter, b_counter;
    r_counter = g_counter = b_counter = 0;
    //It is for RGGB!
    if(DEBUG) cout << "Denoising:" << endl;
    if(DEBUG) cout << "Split raw file into channels" << endl;
    long start = vcos_getmicrosecs64()/1000;
    if(params.internal_bits_per_channel == 8)
        for( i = 0; i < len -2; i +=2, c+=2)
        {
            if(redLine)
            {
                rCh[r_counter] = input[i];//mapR[bayer[i]]++;
                r_counter++;
                gCh[g_counter] = input[i+1];//mapG[bayer[i+1]]++;
                g_counter++;
            } else
            {
                //totalG +=bayer[i];
                //totalB +=bayer[i+1];
                gCh[g_counter] = input[i];//mapG[bayer[i]]++;
                g_counter++;
                bCh[b_counter] = input[i+1];//mapB[bayer[i+1]]++;
                b_counter++;
            }

            if(c >= width)
            {
                c = 0;
                redLine = !redLine;
            }
        }
    else
    {
        for( i = 0; i < len*2 -4; i +=4, c+=4)
        {
            if(redLine)
            {
                rCh[r_counter] = input[i]*256 + input[i+1];//mapR[bayer[i]]++;
                r_counter++;
                gCh[g_counter] = input[i+2]*256 + input[i+3];//mapG[bayer[i+1]]++;
                g_counter++;
            } else
            {
                //totalG +=bayer[i];
                //totalB +=bayer[i+1];
                gCh[g_counter] = input[i]*256 + input[i+1];//mapG[bayer[i]]++;
                g_counter++;
                bCh[b_counter] = input[i+2]*256 + input[i+3];//mapB[bayer[i+1]]++;
                b_counter++;
            }

            if(c >= width*2)
            {
                c = 0;
                redLine = !redLine;
            }
        }
    }

    long end = vcos_getmicrosecs64()/1000;
    if(DEBUG)printf("Split took:%d\n", (end - start));
    //unsigned char * tmp = (unsigned char *)malloc(len/2);
    if(DEBUG) cout << "Denoise G channel" << endl;
    int type = CV_8UC1;
    if(params.internal_bits_per_channel == 10)
        type = CV_16UC1;

    Mat img_R_filtered = filter_single_channel(rCh, width, height, type);
    free(rCh);
    Mat img_G_filtered = filter_single_channel(gCh, width, height, type);
    free(gCh);
    Mat img_B_filtered = filter_single_channel(bCh, width, height, type);
    free(bCh);
    //gCh = tmp;



    rCh = img_R_filtered.data;
    gCh = img_G_filtered.data;
    bCh = img_B_filtered.data;

    i = c = r_counter = g_counter = b_counter = 0;
    //It is for RGGB!
    redLine = true;
    if(params.internal_bits_per_channel == 8)
        for( i = 0; i < len -2; i +=2, c+=2)
        {
            if(redLine)
            {
                input[i] = rCh[r_counter];//mapR[bayer[i]]++;
                r_counter++;
                input[i+1] = gCh[g_counter];//mapG[bayer[i+1]]++;
                g_counter++;
            } else
            {
                //totalG +=bayer[i];
                //totalB +=bayer[i+1];
                input[i] = gCh[g_counter] ;//= input[i];//mapG[bayer[i]]++;
                g_counter++;
                input[i+1] = bCh[b_counter];// = input[i+1];//mapB[bayer[i+1]]++;
                b_counter++;
            }

            if(c >= width)
            {
                c = 0;
                redLine = !redLine;
            }
        }
    else
    {
        for( i = 0; i < len*2 -4; i +=4, c+=4)
        {
            if(redLine)
            {
                input[i] = rCh[r_counter]>>8;//mapR[bayer[i]]++;
                r_counter++;
                input[i+1] = gCh[g_counter];//mapG[bayer[i+1]]++;
                g_counter++;
            } else
            {
                //totalG +=bayer[i];
                //totalB +=bayer[i+1];
                input[i] = gCh[g_counter] ;//= input[i];//mapG[bayer[i]]++;
                g_counter++;
                input[i+1] = bCh[b_counter];// = input[i+1];//mapB[bayer[i+1]]++;
                b_counter++;
            }

            if(c >= width*4)
            {
                c = 0;
                redLine = !redLine;
            }
        }
    }
    img_R_filtered.release();
    img_G_filtered.release();
    img_B_filtered.release();

    return input;

}

Mat Demosaic::filter_single_channel(unsigned char * ch, int w, int h, int type )
{
    Mat img(h, w/2, type, ch, 0);
    Mat img_filtered(h, w/2, type);
    //imread("ddd", CV_LOAD_IMAGE_GRAYSCALE);
    float filter_strength = 2.0;
    int templateWindowSize = 3;
    int searchWindowSize = 11;
    //float filter_strength = 3.0;
    start = vcos_getmicrosecs64()/1000;
   // fastNlMeansDenoising(imgG, img_G_filtered, filter_strength, templateWindowSize, searchWindowSize);
    //GaussianBlur(imgG, img_G_filtered, cv::Size(3,3), 0, 0, BORDER_REFLECT);
    bilateralFilter(img, img_filtered, 3, 7, 7, BORDER_REFLECT);
    end = vcos_getmicrosecs64()/1000;
    if(DEBUG)printf("Denoise of channel took:%d\n", (end - start));
    return img_filtered;
}

Mat Demosaic::blur_edge(Mat img, int border )
{
    Mat pad_img(img.rows + border*2, img.cols + border*2, img.depth());
    Mat blur_img(img.rows + border*2, img.cols + border*2, img.depth());

    copyMakeBorder(img, pad_img, border, border, border, border, BORDER_WRAP);
    GaussianBlur(pad_img, blur_img, cv::Size(2*border+1, 2*border+1), -1);

    return img;
}

Mat Demosaic::get_psf()
{
    int d = 2;
    int k = 30;
    float angle = CV_PI * 45.0 /180.0;
    float noise_level = 0.0;
    float noise = pow(10.0, -0.1* noise_level);

    //defocus psf
    Mat kern;
    kern = Mat::zeros(k,k,CV_8UC1);
    circle(kern, cv::Point(k,k), d, 255, -1, cv::LINE_AA, 1);
    Mat kern_normalized = Mat_<float>(kern);
    kern_normalized = kern_normalized / 255.0;
    ;

    kern_normalized = kern_normalized / cv::sum(kern_normalized)[0];
    return kern_normalized;
}

Mat Demosaic::wiener_decon(Mat img)
{
    Mat real = Mat_<float>(img);
    real = real/255.0;
    Mat img_ft;
    //cout<<"Ready to DFT"<<endl;
    dft(real, img_ft, cv::DFT_COMPLEX_OUTPUT);
    //cout<<"DFT is done"<<endl;

    Mat psf = get_psf();
    //cout<<"WE got PSF"<<endl;


    Mat psf_pad = Mat::zeros(img.size(),CV_32F);

    int kw = psf.rows;
    int kh = psf.cols;

    Mat tmp = psf_pad(cv::Rect(0,0,kw,kh));
    psf.copyTo(tmp);

    //cout<<"PSF padded"<<endl;

    Mat psf_ft;
    dft(psf_pad, psf_ft, cv::DFT_COMPLEX_OUTPUT, kh);

    //cout<<"PSF pad:"<<psf_pad.size() << " d:"<<psf_pad.channels()<<endl;
    //cout<<"PSF FT:"<<psf_ft.size() << " d:"<<psf_ft.channels()<<endl;

    Mat PSF2;
    cv::pow(psf_ft,2, psf_ft);

    //cout<<"PSF squared"<<endl;
    cv::reduce(psf_ft, PSF2, 0, CV_REDUCE_SUM);
        ///cout<<"real:"<<PSF2<<endl;
    //cout<<"PSF reduced:"<<PSF2.size() << " d:"<<PSF2.channels()<<endl;

    /*  OLD*****************
    Mat psf2_pad = Mat::zeros(psf_ft.size(),CV_32F);
    tmp = psf2_pad(cv::Rect(0,0,1,psf_ft.cols));
    PSF2.copyTo(tmp);
    cout<<"real:"<<psf2_pad<<endl;

    Mat planes[] = {Mat(psf2_pad)};
    //merge(planes, 2, psf2_pad);

    //PSF2 = 1.0 / PSF2;
    */
    //

    //cout<<"PSF pad2:"<<psf2_pad.size() << " d:"<<psf2_pad.channels()<<endl;
    //cout<<"PSF FT:"<<psf_ft.size() << " d:"<<psf_ft.channels()<<endl;
    Mat PSF3 = repeat(PSF2,psf_ft.rows, 1 );

    cout<<"PSF2 FT:"<<PSF2.size() << " d:"<<PSF2.channels()<<endl;
    cout<<"PSF3 FT:"<<PSF3.size() << " d:"<<PSF3.channels()<<endl;

    /*int r,c;
    for(r = 0; r< psf_ft.rows; r++)
        for(c = 0; c < psf_ft.cols; c++)
        {
                psf_ft.at<Vec3f>(r,c)[0] = psf_ft.at<Vec3f>(r,c)[0]/PSF2.at<Vec3f>(c)[0];
                psf_ft.at<Vec3f>(r,c)[1] = psf_ft.at<Vec3f>(r,c)[1]/PSF2.at<Vec3f>(c)[1];
        }

    */
    Mat iPSF = psf_ft / PSF3;
    //gemm(psf_ft, PSF2, 1, 0, 0, iPSF);
    //cout<<"iPSF:"<<iPSF.size() << " d:"<<iPSF.channels()<<endl;
    //cout<<"IMG FT:"<<img_ft.size() << " d:"<<img_ft.channels()<<endl;

    Mat res;
    mulSpectrums(img_ft, iPSF, res, 0);
    //cout<<"MulSpectrums"<<endl;

    Mat result;
    idft(res, result, cv::DFT_SCALE|cv::DFT_REAL_OUTPUT);
    //result = result*255;
    Mat converted;
    //cout<<"Result:"<<result<<endl;
    result.convertTo(converted, CV_8UC3);
    //cout<<"iDFT done"<<endl;

    return converted;
}

/*Mat Demosaic::wiener_decon(Mat img)
{



    Mat img_ft, psf_ft;
    Mat psf, psf_pad;

    dft(img, img_ft, cv::DFT_COMPLEX_OUTPUT);
    cout << "DFT 1"<<endl;
    psf_pad = Mat::zeros(img.rows, img.cols, img.depth());

    int kw = psf_pad.rows;
    int kh = psf_pad.cols;

    Mat tmp = psf_pad(cv::Rect(0,0,kw,kh));
    psf = get_psf();
    psf.copyTo(tmp);

    dft(psf_pad, psf_ft, cv::DFT_COMPLEX_OUTPUT, kh);
    cout<<"DFT 2"<<endl;
    //Mat psf_vect(1, complexI_psf.rows, complexI_psf.depth());
    ///reduce( (complexI_psf*complexI_psf), psf_vect, 0, CV_REDUCE_SUM);
    //cout<<complexI_psf<<endl;


    psf_ft = psf_ft*psf_ft;
    Mat planes_psf[] = {Mat_<float>(psf_ft), Mat::zeros(psf_ft.size(), CV_32F)};
    split(psf_ft, planes_psf);

    magnitude(planes_psf[0],planes_psf[1],planes_psf[0]);
    Mat magI = planes_psf[0];
    //cout<<magI<<endl;
    Mat iPSF = psf_ft/(magI+0/*noise);

    cout<<"Division done"<<endl;
    Mat res, res_ft;

    mulSpectrums(img_ft, iPSF, res_ft, 0);
    cout<<"Mulspec"<<endl;
    idft(res_ft, res, cv::DFT_SCALE|cv::DFT_REAL_OUTPUT);
    cout<<"IDFT"<<endl;

    return res;


}*/

/*Mat Demosaic::wiener_decon(Mat img)
{

    Mat planes[] = {Mat_<float>(img), Mat::zeros(img.size(), CV_32F)};
    Mat complexI_img;
    merge(planes, 2, complexI_img);


    Mat img_ft, psf_ft;
    Mat psf, psf_pad;

    dft(complexI_img, complexI_img, cv::DFT_COMPLEX_OUTPUT);
    cout << "DFT 1"<<endl;
    psf_pad = Mat::zeros(img.rows, img.cols, img.depth());

    int kw = psf_pad.rows;
    int kh = psf_pad.cols;

    Mat tmp = psf_pad(cv::Rect(0,0,kw,kh));
    psf = get_psf();
    psf.copyTo(tmp);

    Mat planes_psf[] = {Mat_<float>(psf_pad), Mat::zeros(psf_pad.size(), CV_32F)};
    Mat complexI_psf;
    merge(planes_psf, 2, complexI_psf);

    dft(complexI_psf, complexI_psf, cv::DFT_COMPLEX_OUTPUT, kh);
    cout<<"DFT 2"<<endl;
    //Mat psf_vect(1, complexI_psf.rows, complexI_psf.depth());
    ///reduce( (complexI_psf*complexI_psf), psf_vect, 0, CV_REDUCE_SUM);
    //cout<<complexI_psf<<endl;
    complexI_psf = complexI_psf*complexI_psf;
    cout<<"Complex"<<endl;
    split(complexI_psf, planes_psf);
    cout<<"Split"<<endl;
    magnitude(planes_psf[0],planes_psf[1],planes_psf[0]);
    cout<<"Magnitude"<<endl;
    Mat magI = planes_psf[0];
    cout<<"Mag"<<endl;
    //cout<<magI<<endl;
    Mat iPSF = complexI_psf/(magI/*noise);
    cout<<"iPSF"<<endl;


    Mat res, res_ft;

    mulSpectrums(complexI_img, iPSF, res_ft, 0);
    cout<<"Mulspec"<<endl;
    idft(res_ft, res, cv::DFT_SCALE|cv::DFT_REAL_OUTPUT);
    cout<<"IDFT"<<endl;

    return res;


} */

#endif
void Demosaic::initFullShader()
{
    //cout << ":Initializing shader" << endl;
    // Compile shaders:
    vector<GLuint> shaders;
    //FIXME: !!! Im hardcoded!!!
//    shaders.push_back(compile_shader(GL_VERTEX_SHADER, "/home/pi/FluxPlanet/userland/host_applications/linux/apps/raspicam/debayer_utils/demosaic.vrt"));
//    shaders.push_back(compile_shader(GL_FRAGMENT_SHADER, "/home/pi/FluxPlanet/userland/host_applications/linux/apps/raspicam/debayer_utils/debayer.frg"));
    shaders.push_back(compile_shader(GL_VERTEX_SHADER, "/home/pi/bin/demosaic.vrt"));
    shaders.push_back(compile_shader(GL_FRAGMENT_SHADER, "/home/pi/bin/debayer.frg"));

    //cout << "Link programm" << endl;
    // Link program:
    programObject = link_program(shaders);

    // Delete shaders again:
    for_each(shaders.begin(), shaders.end(), glDeleteShader);

    //cout << "Use progreamm" << endl;
    glUseProgram ( programObject);
    // Get locations:

        // Get locations:
    sourceSize = glGetUniformLocation(programObject, "sourceSize");
    firstRed = glGetUniformLocation(programObject, "firstRed");

    // BGGR = 0,0
    // GRBG = 0,1
    // GBRG = 1,0
    // RGGB = 1,1
    // Set constant uniforms:
    glUniform2f(firstRed, 0, 0  );
    glUniform4f(sourceSize, width, height, 1.0 / width, 1.0 / height);

    // Get the attribute locations
    positionLoc = glGetAttribLocation ( programObject, "vert_pos" );
    texCoordLoc = glGetAttribLocation ( programObject, "texture_pos" );

    // Get the sampler location
    samplerLoc = glGetUniformLocation ( programObject, "source" );

    uWeightR= glGetUniformLocation(programObject, "uWeightR");
    uWeightG= glGetUniformLocation(programObject, "uWeightG");
    uWeightB= glGetUniformLocation(programObject, "uWeightB");

    uHminR = glGetUniformLocation(programObject, "uHminR");
    uHminG = glGetUniformLocation(programObject, "uHminG");
    uHminB = glGetUniformLocation(programObject, "uHminB");

    uBitsH = glGetUniformLocation(programObject, "uBitsH");
    uBitsL = glGetUniformLocation(programObject, "uBitsL");
    uBitsM = glGetUniformLocation(programObject, "uBitsM");

    filterRx = glGetUniformLocation(programObject, "filterRx");
    filterGx = glGetUniformLocation(programObject, "filterGx");
    filterBx = glGetUniformLocation(programObject, "filterBx");
    filterRplus = glGetUniformLocation(programObject, "filterRplus");
    filterGplus = glGetUniformLocation(programObject, "filterGplus");
    filterBplus = glGetUniformLocation(programObject, "filterBplus");

    filterRexp = glGetUniformLocation(programObject, "filterRexp");
    filterGexp = glGetUniformLocation(programObject, "filterGexp");
    filterBexp = glGetUniformLocation(programObject, "filterBexp");

    uStep = glGetUniformLocation(programObject, "uStep");

    // Set constant uniforms:
    glUniform1f(uWeightR, 0.0);
    glUniform1f(uWeightG, 0.0);
    glUniform1f(uWeightB, 0.0);

    glUniform1f(uBitsH, 1.0);
    glUniform1f(uBitsL, 0.0);
    glUniform1f(uBitsM, 1.0);


    //Create frame buffer
    glGenFramebuffers(1, &frameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, frameBuffer);

    GLenum renderBufferId;
    //glGenRenderbuffers(1, &renderBufferId);

    // Load the texture
    textureId = CreateSimpleTexture2D ();
    // Use tightly packed data
    glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );
    textureAwbVignette = CreateSimpleTexture2D ();


    glBindTexture ( GL_TEXTURE_2D, textureAwbVignette);
    glTexImage2D ( GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0 );

    //glBindRenderbuffer(GL_RENDERBUFFER, renderBufferId);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, width, height);

    // Set texture as color attachement
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, textureAwbVignette, 0);

    //glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, renderBufferId);

    //GLenum DrawBuffers[1] = {GL_COLOR_ATTACHMENT0};
    //glDrawBuffers(1, DrawBuffers);
    GLenum st = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if( st == GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT)
    {
        cout << "Failed to create frame buffer GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT\n"<< st <<"\n";
        return;
    }

    if( st == GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS)
    {
        cout << "Failed to create frame buffer GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS\n"<< st <<"\n";
        return;
    }

    if( st == GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT)
    {
        cout << "Failed to create frame buffer GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT\n"<< st <<"\n";
        return;
    }

    if( st == GL_FRAMEBUFFER_UNSUPPORTED)
    {
        cout << "Failed to create frame buffer GL_FRAMEBUFFER_UNSUPPORTED\n"<< st <<"\n";
        return;
    }

    /*int* maxTextureSize = new int[1];
    glGetIntegerv(GL_MAX_TEXTURE_SIZE, maxTextureSize);
    cout << "Texture size:"<< maxTextureSize[0] <<"\n";
*/
    glClearColor ( 0.0f, 0.0f, 0.0f, 1.0f );
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glBindRenderbuffer(GL_RENDERBUFFER, 0);
}

GLuint Demosaic::CreateSimpleTexture2D( )
{
   // Texture object handle
   GLuint textureId;

   // Use tightly packed data
   //glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );

   // Generate a texture object
   glGenTextures ( 1, &textureId );

   // Bind the texture object
   glBindTexture ( GL_TEXTURE_2D, textureId );

   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

   // Set the filtering mode
   glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
   glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );

   return textureId;

}

GLuint Demosaic::compile_shader(GLenum type, const std::string& filename)
{
    //cout << ":Compile shader" << endl;
    char *shader_text = NULL;
    int shader_length = 0;

    // Read file contents:
    //   Open file:
    //cout << ": : Open File" << endl;
    ifstream file_stream(filename.c_str());
    if(!file_stream.is_open()){
        cout << ": : Cannot open file!" << filename.c_str() << endl;
    }


    //   Get file length:
    //cout << ": : File length" << endl;
    file_stream.seekg(0, ios::end);
    shader_length = file_stream.tellg();
    file_stream.seekg(0, ios::beg);

    //   Read into buffer:
    //cout << ": : Read to buffer. length="<< shader_length << endl;
    shader_text = new char[shader_length];
    file_stream.read(shader_text, shader_length);
    //cout << ": : Read to buffer. Done"<< endl;

    //    Close file:
    file_stream.close();


    // Create OpenGL shader:
    //cout << ": : Create shader" << endl;
    const GLuint handle = glCreateShader(type);
    const char *const_shader_text = shader_text;
    glShaderSource(handle, 1, &const_shader_text, &shader_length);
    delete[] shader_text;
    glCompileShader(handle);

    // Check for errors:
    //cout << ": : Check for errors" << endl;
    GLint status;
    glGetShaderiv(handle, GL_COMPILE_STATUS, &status);
    if(status == GL_FALSE)
    {
        // Get info log:
        GLint log_length;
        glGetShaderiv(handle, GL_INFO_LOG_LENGTH, &log_length);
        GLchar *log_text = new GLchar[log_length];
        glGetShaderInfoLog(handle, log_length, NULL, log_text);

        // Print log:
        cout << "Compilation of \"" << filename << "\" failed:\n" << log_text << "\n";
        delete[] log_text;

//        throw GLException("shader compilation failed");
    }

    return handle;
}

GLuint Demosaic::link_program(const vector<GLuint>& shaders)
{
    typedef vector<GLuint>::const_iterator IT;

    // Create OpenGL program:
    const GLuint handle = glCreateProgram();

    // Attach the shaders:
    for(IT it = shaders.begin(); it != shaders.end(); ++it)
        glAttachShader(handle, *it);

    // Link:
    glLinkProgram(handle);

    // Detach the shaders:
    for(IT it = shaders.begin(); it != shaders.end(); ++it)
        glDetachShader(handle, *it);

    // Check for errors:
    GLint status;
    glGetProgramiv(handle, GL_LINK_STATUS, &status);
    if(status == GL_FALSE)
    {
        // Get info log:
        GLint log_length;
        glGetProgramiv(handle, GL_INFO_LOG_LENGTH, &log_length);
        GLchar *log_text = new GLchar[log_length];
        glGetProgramInfoLog(handle, log_length, NULL, log_text);

        // Print log:
        cout << "Linking of shader program failed:\n" << log_text << "\n";
        delete[] log_text;

//        throw GLException("program linking failed");
    }

    return handle;
}

void Demosaic::initColorWeights(unsigned char* rgb, int len) {
    int i = 0;
    long int totalR = 0;
    long int totalG = 0;
    long int totalB = 0;
    for(i = 0; i < len; i+=3){
        totalR+=rgb[i];
        totalG+=rgb[i+1];
        totalB+=rgb[i+3];
    }

    long int totalHighest = 0;
    totalHighest = totalG;
    if(totalG > totalHighest)
        totalHighest = totalG;
    if(totalB > totalHighest)
        totalHighest = totalB;

    weightGreen = (float)totalHighest/(float)totalG;
    weightRed = (float) totalHighest/(float)totalR;
    weightBlue = (float)totalHighest/(float)totalB;
    //if(DEBUG) printf("TotalH %ld RGB %ld %ld %ld\n",totalHighest,  totalR, totalG, totalB);
    //if(DEBUG) printf("Weights RGB %f %f %f\n", weightRed, weightGreen, weightBlue);

}

void Demosaic::whitePatch(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params)
{
    bool redLine = true;
    int i =0;
    int c = 0;
    int rMax = 0;
    int gMax = 0;
    int bMax = 0;
    for( i = 0; i < len -2; i +=2, c+=2)
    {
        if(redLine)
        {
            if(bayer[i] > rMax)
                rMax = bayer[i];
            if(bayer[i+1] > gMax)
                gMax = bayer[i+1];
        } else
        {
            if(bayer[i] > gMax)
                gMax = bayer[i];
            if(bayer[i+1] > bMax)
                bMax = bayer[i+1];
        }

        if(c >= width)
        {
            c = 0;
            redLine = !redLine;
        }
    }

    weightRed = (float)gMax/(float)rMax;
    weightBlue = (float) gMax/ (float) bMax;
    weightGreen = 1.f;
    cout<< "Weights" << weightRed <<"," << weightGreen<<","<<weightBlue<<endl;
   if(DEBUG) printf("MAX RGB %d %d %d\n", rMax, gMax, bMax);
   if(DEBUG) printf("Weights RGB %f %f %f\n", weightRed, weightGreen, weightBlue);
}

void Demosaic::grayWorld(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params)
{
    bool redLine = false;
    int i =0;
    int c = 0;
    long int totalR = 0;
    long int totalG = 0;
    long int totalB = 0;

    //It is for RGGB!
    for( i = 0; i < len -2; i +=2, c+=2)
    {
        if(redLine)
        {
            totalR+=bayer[i];
            totalG+=bayer[i+1];
        } else
        {
            totalG +=bayer[i];
            totalB +=bayer[i+1];
        }

        if(c >= width)
        {
            c = 0;
            redLine = !redLine;
        }
    }

    float avgR = 4.0 * totalR/len;
    float avgG = 2.0 * totalG/len;
    float avgB = 4.0 * totalB/len;
/*
    weightRed = (float)avgG/(float)avgR;
    weightBlue = (float) avgG/ (float) avgB;
    weightGreen = 1.f;
    */
    params->weight_red = (float)avgG/(float)avgR;
    params->weight_green  = 1.f;
    params->weight_blue  = (float) avgG/ (float) avgB;
    //if(DEBUG) printf("MAX RGB %d %d %d\n", rMax, gMax, bMax);
    if(DEBUG) printf("Weights RGB %f %f %f\n", params->weight_red, params->weight_green, params->weight_blue);

}

void Demosaic::awbColorWeights(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params)
{
    bool redLine = false;
    int i =0;
    int c = 0;
    long int totalR = 0;
    long int totalG = 0;
    long int totalB = 0;

    //It is for RGGB!
    for( i = 0; i < len -2; i +=2, c+=2)
    {
        if(redLine)
        {
            totalR+=bayer[i];
            totalG+=bayer[i+1];
        } else
        {
            totalG +=bayer[i];
            totalB +=bayer[i+1];
        }

        if(c >= width)
        {
            c = 0;
            redLine = !redLine;
        }
    }

        long int totalHighest = totalG;

        if(totalG > totalHighest)
            totalHighest = totalG;
        if(totalB > totalHighest)
            totalHighest = totalB;


    weightGreen = (float)totalHighest/(float)totalG;
    weightRed = (float) totalHighest/(float)totalR;
    weightBlue = (float)totalHighest/(float)totalB;
    //if(DEBUG) printf("MAX RGB %d %d %d\n", rMax, gMax, bMax);
    //if(DEBUG) printf("Weights RGB %f %f %f\n", weightRed, weightGreen, weightBlue);

}

void Demosaic::calculateHistogramMap(unsigned char* interpolatedData){
 /*   if(doHistogramMap && (histogramMin != 0 || histogramMax != 0))
    {

        int index = 0;
        int totalSum = 0;
        int map[256] = {0};
        int perMap[256] = {0};
        for(index = 0 ; (index+2) < (height*width*3) ; index +=3)
        {
            int mapIndex = (int)( 0.2989*interpolatedData[index] + 0.5870*interpolatedData[index+1] + 0.1141*interpolatedData[index+2]);

            if(mapIndex > 20 && mapIndex < 240) {
                map[mapIndex]++;
                totalSum++;
            }

        }

        int tempSum = 0;
        for(index = 0 ; index <= 0xFF ; index++)
        {
            tempSum += map[index];
            int per = (int)((float)tempSum*10000/totalSum);
            //printf("MAP[%d] = %d %i percent\n", index, map[index], per);
            perMap[index] = per;

        }
        int threasholdMin = histogramMin;
        int minFound = 0;
        int threasholdMax = histogramMax;
        for(index = 0 ; index < 0xFF ; index++)
        {
            if(minFound == 0 && perMap[index] <= threasholdMin) {
                histogramMin = index;
                minFound = 1;
            }
            if(perMap[index] <= 10000-threasholdMax) {
                histogramMax = index;
            }
        }
        //if(DEBUG) printf("Histogran min %i max %d\n", histogramMin, histogramMax);
    }
    else
    {
        histogramMin = 0;
        histogramMax = 255;
    }*/
}

void Demosaic::gimp_awb(unsigned char* bayer, int width, int len, DEBAYER_PARAMS* params)
{
    register int i;
    int rmin, rmax, gmin, gmax, bmin, bmax;
    int red, green, blue;
    float treshold  = 0.001;
    int discardPx = treshold * len/3;

    int mapR[256] ;
    int mapG[256];
    int mapB[256] ;

    memset(mapR, 0, 256*sizeof(int));
    memset(mapG, 0, 256*sizeof(int));
    memset(mapB, 0, 256*sizeof(int));

    bool redLine = true;
    i =0;
    int c = 0;
    //It is for RGGB!
    for( i = 0; i < len -2; i +=2, c+=2)
    {
        if(redLine)
        {
            mapR[bayer[i]]++;
            mapG[bayer[i+1]]++;
        } else
        {
            //totalG +=bayer[i];
            //totalB +=bayer[i+1];
            mapG[bayer[i]]++;
            mapB[bayer[i+1]]++;
        }

        if(c >= width)
        {
            c = 0;
            redLine = !redLine;
        }
    }

  /*  for(i = 0; i < len; i +=3)
    {
        mapR[rgb[i]]++;
        mapG[rgb[i+1]]++;
        mapB[rgb[i+2]]++;
    }
*/
    int pixelsR = 0;
    int pixelsG = 0;
    int pixelsB = 0;
    for(i = 0 ; i < 255; i++)
    {
        if(pixelsR <= discardPx)
        {
            pixelsR += mapR[i];
            rmin=i+1;
        }

        if(pixelsG <= discardPx)
        {
            pixelsG += mapG[i];
            gmin=i+1;
        }

        if(pixelsB <= discardPx)
        {
            pixelsB += mapB[i];
            bmin=i+1;
        }
    }
    pixelsR = 0;
    pixelsG = 0;
    pixelsB = 0;
    for(i = 255 ; i > 0; i--)
    {
        if(pixelsR <= discardPx)
        {
            pixelsR += mapR[i];
            rmax=i-1;
        }

        if(pixelsG <= discardPx)
        {
            pixelsG += mapG[i];
            gmax=i-1;
        }

        if(pixelsB <= discardPx)
        {
            pixelsB += mapB[i];
            bmax=i-1;
        }

    }

    //cout << " RGB MAX" << rmax << " "<< gmax << " "<< bmax << " "<<endl;
    //cout << " RGB MIN" << rmin << " "<< gmin << " "<< bmin << " "<<endl;
    float dR = (float)(rmax - rmin)/255.0;
    float dG = (float)(gmax - gmin)/255.0;
    float dB = (float)(bmax - bmin)/255.0;
    float mR = (float) 1.0/dR;
    float mG = (float) 1.0/dG;
    float mB = (float) 1.0/dB;

    params->weight_red = mR;
    params->weight_green  = mG;
    params->weight_blue  = mB;

    minRed = (float) rmin/255.0;
    minGreen = (float) gmin/255.0;
    minBlue = (float) bmin/255.0;
/*
    for(i = 0; i < len; i +=3)
    {
        rgb[i]   = (clamp((rgb[i]   - rmin) * mR));
        rgb[i+1] = (clamp((rgb[i+1] - gmin) * mG));
        rgb[i+2] = (clamp((rgb[i+2] - bmin) * mB));


        //   RGB to XYZ
        rgb[i] = 0.243836* rgb[i] +  1.083527 * rgb[i+1] -1.266055 * rgb[i+2];
        rgb[i+1] = -0.582773* rgb[i] +  2.210038 * rgb[i+1] -1.635728 * rgb[i+2];
        rgb[i+2] = -0.481200* rgb[i] +  0.312275 * rgb[i+1] + rgb[i+2]* 0.600831;

        //XYZ to sRGB

        /*rgb[i] = clamp(3.2410* rgb[i] -  1.5374 * rgb[i+1] - rgb[i+2]* 0.4986);
        rgb[i+1] = clamp(-0.9692* rgb[i] +  1.8760 * rgb[i+1] + rgb[i+2]* 0.0416);
        rgb[i+2] = clamp(0.0556* rgb[i] - 0.2040 * rgb[i+1] + rgb[i+2]* 1.0570);
        */

/*    { { 0.436083, 0.385083, 0.143055 },
    { 0.222507, 0.716888, 0.060608 },
    { 0.013930, 0.097097, 0.714022 } };


        Matrix = 0.243836 1.083527 -1.266055
         -0.582773 2.210038 -1.635728
         -0.481200 0.312275 0.600831
Matrix = 0.243836 1.083527 -1.266055
*/
    //}

    float val = 0.0;
    //GAMMA
/*  for(i = 0; i < len; i ++)
    {
        val = (float) rgb[i]/255.0;
        if(val <=0.00304)
            val = 12.92 * val;
        else
            val = 1.055 * pow(val, 1/2.4) - 0.055;
        rgb[i] = clamp(val*255);
    }
    */
}
/*
const double xyz_rgb[3][3] = {          /* XYZ from RGB
  { 0.412453, 0.357580, 0.180423 },
  { 0.212671, 0.715160, 0.072169 },
  { 0.019334, 0.119193, 0.950227 } };
  */

//Robust Automatic White Balance Algorithm using Gray Color Points in Images
void Demosaic::IWB(unsigned char* orig_rgb, int width, long len)
{
    int maxIter = 10;
    float T = 0.1321;
    float u = 0.0312;
                  //R G B
    float gain[] = {1,1,1};
    unsigned char *yuv;
    unsigned char *graypoints;
    unsigned char *rgb;
    yuv = (unsigned char *)malloc(len);
    graypoints = (unsigned char *)malloc(len);




    int t=0;
    memcpy(rgb, orig_rgb, len);
    for(t = 0; t < maxIter; t ++)
    {
        long  grayLen=0;
        long i;
        for(i = 0; i < len; i +=3)
        {
            yuv[i]= 0.299*rgb[i] + 0.587*rgb[i+1] + 0.114*rgb[i+2];
            yuv[i+1]= (-0.299)*rgb[i] + (-0.587)*rgb[i+1] + 0.886*rgb[i+2];
            yuv[i+2]= 0.701*rgb[i] + (-0.587)*rgb[i+1] + (-0.114)*rgb[i+2];
            float F = (abs(yuv[i+1]) + abs(yuv[i+2]))/yuv[i];
            if(F < T)
            {
                graypoints[grayLen] = yuv[i+1];
                grayLen++;
                graypoints[grayLen] = yuv[i+2];
                grayLen++;
            }
        }

        cout << "Gray points found:" << grayLen<<endl;

        float Uavg = 0;
        float Vavg = 0;
        for(i = 0; i< grayLen; i+=2)
        {
            Uavg+=graypoints[i];
            Vavg+=graypoints[i+1];
        }
        Uavg=2* Uavg/grayLen;
        Vavg=2* Vavg/grayLen;

        cout << "U:" << Uavg << "V:"<< Vavg<<endl;
        int gainRed = 0;
        int ch = 0;
        float err = 0;
        if(Uavg < Vavg)
        {
            ch = 0; //RED
            err = -Vavg;
        } else
        {
            ch = 2;//BLUE
            err = -Uavg;
        }
        gain[ch] = gain[ch] + u * k_of_(err);
        //yuv = rgb2YUV(rgb,width, len);

        for(i = 0; i < len; i +=3)
        {
            rgb[i]  =orig_rgb[i]  *gain[0];
            rgb[i+1]=orig_rgb[i+1]*gain[1];
            rgb[i+2]=orig_rgb[i+2]*gain[2];
        }
        cout << "IWB gains:" << gain[0] <<","<<gain[1]<<","<<gain[2]<<endl;
    }
    free(yuv);
    free(graypoints);
    free(rgb);
    cout << "IWB gains FINAL:" << gain[0] <<","<<gain[1]<<","<<gain[2]<<endl;
}

/*unsigned char* rgb2YUV(unsigned char* rgb, int width, int len)
{
    float[][] conv = {{0.299 0.587 0.114},{-0.299 -0.587 0.886},{0.701 -0.587 -0.114}}; //rgb to yuv
    unsigned char *yuv;
    yuv = (unsigned char *)malloc(len);
    int i;
    for(i = 0; i < len; i +=3)
    {
        yuv[i]= 0.299*rgb[i] + 0.587*rgb[i+1] + 0.114*rgb[i+2];
        yuv[i+1]= (-0.299)*rgb[i] + (-0.587)*rgb[i+1] + 0.886*rgb[i+2];
        yuv[i+2]= 0.701*rgb[i] + (-0.587)*rgb[i+1] + (-0.114)*rgb[i+2];
    }

    return yuv;
}*/

float Demosaic::k_of_(float x)
{
    float res = 0;
    float treshA = 0.8;
    float treshB = 0.15;
    if(abs(x) >= treshA)
        res = 2 * sign(x);
    else
        if( treshA > abs(x) && abs(x) >=treshB)
            res = sign(x);
        else
            res = 0;
    return res;
}

int Demosaic::sign(float x)
{
    return (x > 0) ? 1 : ((x < 0) ? -1 : 0);
}
void Demosaic::sensorRGB2sRGBspace(unsigned char* bayer, int width, int len, DEBAYER_PARAMS params)
{
    int i = 0;
    int step = 1;
    if(params.internal_bits_per_channel == 10)
    {
        step = 2;
    }
    //cout << "Steps is: " << step<<endl;
    int min = 0;
    for(i = 0; i < len*step; i+=step )
    {
        /*
        if(i == 0)
            min = bayer[i];
        if(bayer[i] < min)
            min = bayer[i];
        */

        if(bayer[i] < 16)
            bayer[i] = 0;
        else
            bayer[i] = bayer[i] - 16;
    }

    //cout << "Minimum is: " << min<<endl;
    //TODO:
}

int Demosaic::clamp(int color)
{
    if(color < 0)
        return 0;
    if(color > 255)
        return 255;
    return color;
}

/*void Demosaic::cumhist(int* histogram, int* cumhistogram)
{
    cumhistogram[0] = histogram[0];

    for(int i = 1; i < 256; i++)
    {
        cumhistogram[i] = histogram[i] + cumhistogram[i-1];
    }
}*/

void Demosaic::hist_equalize(unsigned char* rgb, int width, long len)
{
    long i;
    int rmin, rmax, gmin, gmax, bmin, bmax;
    int red, green, blue;
    float treshold  = 0.0005;
    long discardPx = treshold * len/3;

    cout << "To discard" << discardPx<<endl;
    long mapR[256] ;
    long mapG[256];
    long mapB[256] ;

    for(i=0; i < 256; i++)
    {
        mapR[i] = 0;
        mapG[i] = 0;
        mapB[i] = 0;
    }
    for(i = 0; i < len; i +=3)
    {
        red   = rgb[i];
        green = rgb[i+1];
        blue  = rgb[i+2];

        mapR[red]++;
        mapG[green]++;
        mapB[blue]++;
    }
    //cout << " RGB MAX" << rmax << " "<< gmax << " "<< bmax << " "<<endl;
    //cout << " RGB MIN" << rmin << " "<< gmin << " "<< bmin << " "<<endl;
    long size = len/3;
    float alpha = 255.0/size;

    // Calculate the probability of each intensity
    float probR[256];
    float probG[256];
    float probB[256];
    for( i = 0; i < 256; i++)
    {
         probR[i] = (double)mapR[i] / size;
         probG[i] = (double)mapG[i] / size;
         probB[i] = (double)mapB[i] / size;
    }

    // Generate cumulative frequency histogram
    int cumhistR[256];
    int cumhistG[256];
    int cumhistB[256];

    cumhistR[0] = probR[0];
    cumhistG[0] = probG[0];
    cumhistB[0] = probB[0];

    for(int i = 1; i < 256; i++)
    {
        cumhistR[i] = probR[i] + cumhistR[i-1];
        cumhistG[i] = probG[i] + cumhistG[i-1];
        cumhistB[i] = probB[i] + cumhistB[i-1];
    }
    //cumhist(&probR,&cumhistR);
    //cumhist(&probG,&cumhistG);
    //cumhist(&probB,&cumhistB);

    // Scale the histogram
    int SkR[256];
    int SkG[256];
    int SkB[256];
    for( i = 0; i < 256; i++)
    {
        SkR[i] = (double)cumhistR[i] * alpha;
        SkG[i] = (double)cumhistG[i] * alpha;
        SkB[i] = (double)cumhistB[i] * alpha;
    }

    /*// Generate the equlized histogram
    float PsSkR[256];
    float PsSkG[256];
    float PsSkB[256];
    for(int i = 0; i < 256; i++)
    {
        PsSkR[i] = 0;
        PsSkG[i] = 0;
        PsSkB[i] = 0;
    }

    for(int i = 0; i < 256; i++)
    {
        PsSkR[SkR[i]] += probR[i];
        PsSkG[SkG[i]] += probG[i];
        PsSkB[SkB[i]] += probB[i];
    }

    int finalR[256];
    int finalG[256];
    int finalB[256];
    for(int i = 0; i < 256; i++)
    {
        finalR[i] = PsSkR[i]*255;
        finalG[i] = PsSkG[i]*255;
        finalB[i] = PsSkB[i]*255;
    }
*/

    for(i = 0; i < len; i +=3)
    {
        red   = rgb[i];
        green = rgb[i+1];
        blue  = rgb[i+2];

        rgb[i] = clamp(SkR[red]);
        rgb[i+1]= clamp(SkG[green]);
        rgb[i+2]= clamp(SkB[blue]);
    }


    //for(int y = 0; y < image.rows; y++)
      //  for(int x = 0; x < image.cols; x++)
        //    new_image.at<uchar>(y,x) = clamp(Sk[image.at<uchar>(y,x)]); //clamp

    /*cout << " RGB MAX" << rmax << " "<< gmax << " "<< bmax << " "<<endl;
    cout << " RGB MIN" << rmin << " "<< gmin << " "<< bmin << " "<<endl;

    for(i = 0; i < len; i +=3)
    {
        rgb[i] = clamp((rgb[i] - rmin) * (255 - 0)/(rmax -  rmin));
        rgb[i+1] = clamp((rgb[i+1] - gmin) * (255 - 0)/(gmax -  gmin));
        rgb[i+2] = clamp((rgb[i+2] - bmin) * (255 - 0)/(bmax -  bmin));
    }*/
}

void Demosaic::equalizeHistogram(unsigned char * pdata, int width, int height, int max_val)
{
    int  total = width*height;
    int n_bins = max_val + 1;

    // Compute histogram
    vector<int> hist(n_bins, 0);
    for (int i = 0; i < total; ++i) {
        hist[pdata[i]]++;
    }
    cout << "Histogramm computed."<<endl;
    float treshold  = 0.0005;
    int discardPx = treshold * total;
    int pixels = 0;
    int jj = 0;
    while( (pixels+=hist[jj] )< discardPx && jj < max_val)
    {
        hist[jj] = 0;
        jj++;
    }
    cout << "Start cut. Max:"<<max_val<<endl;
    pixels = 0;
    jj = max_val;
    while((pixels+=hist[jj] )< discardPx && jj > 0)
    {
        cout << jj<<endl;
        hist[jj] = 0;
        jj--;
    }
    cout << "Tail cut."<<endl;
    // Build LUT from cumulative histrogram

    // Find first non-zero bin
    int i = 0;
    while (!hist[i]) ++i;

    if (hist[i] == total) {
        for (int j = 0; j < total; ++j) {
            pdata[j] = i;
        }
        return;
    }

    // Compute scale
    float scale = (n_bins - 1.f) / (total - hist[i]);

    // Initialize lut
    vector<int> lut(n_bins, 0);
    i++;

    int sum = 0;
    for (; i < hist.size(); ++i) {
        sum += hist[i];
        // the value is saturated in range [0, max_val]
        lut[i] = max(0, min(int(round(sum * scale)), max_val));
    }

    // Apply equalization
    for (int i = 0; i < total; ++i) {
        pdata[i] = lut[pdata[i]];
    }
}

void Demosaic::normalizeHistogram(unsigned char* rgb, int width, long len)
{
   register int x, y;
   register int i, j;
   int mu, sigma;                  // Gaussian parameters
   unsigned int lutR[256], lutG[256], lutB[256];            // Look-Up Table (LUT)
   unsigned int nC[256], n;         // Histogram of "this" image, number of pixels in image
   double pCR[256], cCR[256];         // Image intencity value occurance probability, Cumalative Distribution Function of pC
   double pNR[256], cNR[256];         // Normal intencity value occurance probability, Cumalative Distribution Function of pN

   double pCG[256], cCG[256];         // Image intencity value occurance probability, Cumalative Distribution Function of pC
   double pNG[256], cNG[256];         // Normal intencity value occurance probability, Cumalative Distribution Function of pN

   double pCB[256], cCB[256];         // Image intencity value occurance probability, Cumalative Distribution Function of pC
   double pNB[256], cNB[256];         // Normal intencity value occurance probability, Cumalative Distribution Function of pN
   int red, green, blue;
   memset(nC, 0, 256*sizeof(unsigned int));
   n = width * height;
   mu = 256 / 2; sigma = mu;
   float Pi = 3.1415926;

    long mapR[256] ;
    long mapG[256];
    long mapB[256] ;

    for(i=0; i < 256; i++)
    {
        mapR[i] = 0;
        mapG[i] = 0;
        mapB[i] = 0;
    }
    for(i = 0; i < len; i +=3)
    {
        red   = rgb[i];
        green = rgb[i+1];
        blue  = rgb[i+2];

        mapR[red]++;
        mapG[green]++;
        mapB[blue]++;
    }
    //
 /*  std::vector<Mat> vChannels(this->channels());
   split(*this, vChannels);
   for (x = 0; x < this->cols; x++)
      for (y = 0; y < this->rows; y++) {
         int val = 0;
         for (i = 0; i < this->channels(); i++) val += vChannels[i].at<unsigned char>(y, x);
         val /= this->channels();   // Graff px style
         nC[val]++;
      }
    */


    for (i=0; i < 256; i++) {
      pCR[i] = static_cast<double>(mapR[i]) / n;
      pCG[i] = static_cast<double>(mapG[i]) / n;
      pCB[i] = static_cast<double>(mapB[i]) / n;
      // Calculating cumulative distribution
      cCR[i] = (i==0) ? pCR[i] : cCR[i-1] + pCR[i];
      cCG[i] = (i==0) ? pCG[i] : cCG[i-1] + pCG[i];
      cCB[i] = (i==0) ? pCB[i] : cCB[i-1] + pCB[i];
   }

   // Creating the form of the normal histogram, and corresponding CDF
   for(i = 0; i < 256; i++) {
      pNR[i] = exp(-pow((double) i - mu, 2) / (2*sigma*sigma)) / sqrt(2*Pi*sigma*sigma);
      pNG[i] = exp(-pow((double) i - mu, 2) / (2*sigma*sigma)) / sqrt(2*Pi*sigma*sigma);
      pNB[i] = exp(-pow((double) i - mu, 2) / (2*sigma*sigma)) / sqrt(2*Pi*sigma*sigma);
      // Calculating cumulative distribution
      cNR[i] = (i==0) ? pNR[i] : cNR[i-1] + pNR[i];
      cNG[i] = (i==0) ? pNG[i] : cNG[i-1] + pNG[i];
      cNB[i] = (i==0) ? pNB[i] : cNB[i-1] + pNB[i];
   }

   //Creating look-up table (LUT)
      j = 0;
   for (i = 0; i < 256; i++) {
      while((j < 255) && (abs(cNR[j + 1] - cCR[i]) <= abs(cNR[j] - cCR[i]))) j++;
      lutR[i] = j;
   }
         j = 0;
   for (i = 0; i < 256; i++) {
      while((j < 255) && (abs(cNG[j + 1] - cCG[i]) <= abs(cNG[j] - cCG[i]))) j++;
      lutG[i] = j;
   }
         j = 0;
   for (i = 0; i < 256; i++) {
      while((j < 255) && (abs(cNB[j + 1] - cCB[i]) <= abs(cNB[j] - cCB[i]))) j++;
      lutB[i] = j;
   }

   //result transform
    for(i = 0; i < len; i +=3)
    {
        red   = rgb[i];
        green = rgb[i+1];
        blue  = rgb[i+2];
        rgb[i] =
        (lutR[red]);
        rgb[i+1] = static_cast<unsigned char>(lutG[green]);
        rgb[i+2] = static_cast<unsigned char>(lutB[blue]);
        //vChannels[i].at<unsigned char>(y, x) = static_cast<unsigned char>(lut[val]);
    }
   //merge(vChannels, *this);
   //vChannels.clear();
}