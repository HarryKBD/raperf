 #ifdef __cplusplus
 #define EXTERNC extern "C"
 #else
 #define EXTERNC
 #endif

 typedef void* demosaic_t;

 EXTERNC demosaic_t demosaic_init(int width, int height, int brightness, int contrast);
 EXTERNC void demosaic_destroy(demosaic_t mytype);
 EXTERNC void demosaic_process(demosaic_t self, unsigned char * inGray, unsigned char * outRGB);
 EXTERNC void demosaic_process_filters(demosaic_t self, unsigned char * inRGB, unsigned char * outRGB, float brightnes, float contrast,
                                 float wR, float wG, float wB, float bR, float bG, float bB, float exp, float gamma, float hMin, float hMax);
 EXTERNC void demosaic_process_filters_step2(demosaic_t untyped_self, unsigned char * inRGB, unsigned char * outRGB, float brightnes, float contrast, float hMin, float hMax);
 EXTERNC void demosaic_process_filters_step1(demosaic_t untyped_self, unsigned char * inRGB, unsigned char * outRGB, float wR, float wG, float wB, float bR, float bG, float bB, float exp, float gamma);

 EXTERNC void debayer_process(demosaic_t self, unsigned char * inGray, unsigned char * outRGB, float brightnes, float contrast,
                                 float bR, float bG, float bB, float exp, float gamma, float hMin, float hMax, int ibpch, int awb, bool dnz_bayer, bool dnz_rgb, bool sharp);
 #undef EXTERNC