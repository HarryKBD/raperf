#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
//#include <sys/types.h>
#include <sys/stat.h>
#include "RaspiCLI.h"
#include "debayer_utils/demosaic_connector.h"
#include "interface/vcos/vcos.h"

#define CommandInput        1
#define CommandOutput       2
#define CommandWidth        3
#define CommandHeight       4
#define CommandInputFormat  5
#define CommandBrightness   6
#define CommandContrast     7
#define CommandBalanceR     8
#define CommandBalanceG     9
#define CommandBalanceB     10
#define CommandExposure     11
#define CommandGamma        12
#define CommandHistogramMin 13
#define CommandHistogramMax 14
#define CommandOutputDir    15
#define CommandInternalBpCh 16
#define CommandAWB_METHOD   17
#define Command_Denoise_bayer_ON   18
#define Command_Denoise_RGB_ON     19
#define Command_SHARP_ON           20

#define INPUT_FORMAT_RAW8  1
#define INPUT_FORMAT_RAW10 2

#define VERSION_STRING "v1.0.1"
#define DEBUG 0
#define PROGRESS 1

static COMMAND_LIST cmdline_commands[] =
{
    { CommandInput,         "-input",     "i",  "Input raw bayer data", 1 },
    { CommandOutput,        "-output",    "o",  "Output file", 1 },
    { CommandOutputDir,     "-outputDir", "od", "Output folder", 1 },
    { CommandWidth,         "-width",     "w",  "Set image width <size>", 1 },
    { CommandHeight,        "-height",    "h",  "Set image height <size>", 1 },
    { CommandInputFormat,   "-format",    "f",  "Set input format RAW8 or RAW10. RAW8 by default", 1 },
   // { CommandBrightness,    "-brightnes", "b",  "Set image brightnes DISABLED", 1 },
    { CommandContrast,      "-contrast",  "c",  "Set image contrast", 1 },
    { CommandBalanceR,      "-balanceR",  "br", "Set balance of red channel. Used in AWB Fixed mode", 1 },
    { CommandBalanceG,      "-balanceG",  "bg", "Set balance of gree channel. Used in AWB Fixed mode", 1 },
    { CommandBalanceB,      "-balanceB",  "bb", "Set balance of blue channel. Used in AWB Fixed mode", 1 },
   //  { CommandExposure,      "-exposure",  "e",  "Set image contrast DISABLED", 1 },
    { CommandGamma,         "-gamma",     "g",  "Set gamma value. 5 is default", 1 },
   // { CommandHistogramMin,  "-hMin",      "hmn",  "DISABLED", 1 },
   // { CommandHistogramMax,  "-hMax",      "hmx",  "DISABLED", 1 },
    { CommandInternalBpCh,  "-internalbpch",     "ibpch",  "Internal format. Bits per channel", 1 },
    { CommandAWB_METHOD,                "-AWB",           "awb",  "AWB mode: 0 - Off, 1 - Fixed, 2 - GIMP, 3 - Gray world, 4 - White patch, 5 - Weighted. 1 is used by default", 1 },
    { Command_Denoise_bayer_ON,         "-denoise_bayer",     "dnzb",  "1 to enable denoise of bayer data", 1 },
    { Command_Denoise_RGB_ON,           "-denoise_rgb",     "dnzrgb",  "1 to enable denoise of rgb data", 1 },
    { Command_SHARP_ON,                 "-sharp",     "shrp",  "1 to enable sharpening", 1 },
};
static int cmdline_commands_size = sizeof(cmdline_commands) / sizeof(cmdline_commands[0]);

char * inputFile;
char * outputDir;
char * outputFile;
int width, height;
int internalBpCh = 8;
int brightnes = 0, contrast = 0;
int dfile;
int inputFormat = INPUT_FORMAT_RAW8;
int awb = 0;
bool dnz_rgb = false;
bool dnz_bayer = false;
bool sharp = false;

float weightGreen = 1;
float weightRed = 1;
float weightBlue = 1;

int balanceR = 255;
int balanceG = 255;
int balanceB = 255;

int exposure = 0;
float gammaVal = 5.f;

int histogramMax = 255;
int histogramMin = 0;
int doHistogramMap = 0;

static int parse_cmdline(int argc, const char **argv)
{
    int i;
    int valid = 1;
    for (i=1 ; i < argc ; i++)
    {
        int num_parameters;
        if (!argv[i])
            continue;

        if (argv[i][0] != '-')
        {
            valid = 0;
            continue;
        }
        int command_id = raspicli_get_command_id(cmdline_commands, cmdline_commands_size, &argv[i][1], &num_parameters);

        // If we found a command but are missing a parameter, continue (and we will drop out of the loop)
        if (command_id != -1 && num_parameters > 0 && (i + 1 >= argc) )
            continue;

        //  We are now dealing with a command line option
        switch (command_id)
        {

            case CommandOutput:  // output filename
            {
                int len = strlen(argv[i + 1]);
                if (len)
                {
                    outputFile = malloc(len + 1);
                    //vcos_assert(outputDir);
                    if (outputFile)
                        strncpy(outputFile, argv[i + 1], len+1);
                    i++;
                    //ofile = fopen(directory, "wb");
                    //dfile = open(outputDir,  O_CREAT|O_WRONLY, S_IRUSR|S_IWUSR);
                    //dumfile = fopen("/home/pi/dum.data", "wb");
                    fprintf(stdout, "Output file given %s\n", outputFile);
                    fflush(stdout);
                }
                else
                    valid = 0;
                break;
            }
            case CommandOutputDir:
            {
                int len = strlen(argv[i + 1]);
                if (len)
                {
                    outputDir = malloc(len + 1);
                    //vcos_assert(outputDir);
                    if (outputDir)
                        strncpy(outputDir, argv[i + 1], len+1);
                    i++;
                    //ofile = fopen(directory, "wb");
                    //dfile = open(outputDir,  O_CREAT|O_WRONLY, S_IRUSR|S_IWUSR);
                    //dumfile = fopen("/home/pi/dum.data", "wb");
                    fprintf(stdout, "Output folder given %s\n", outputDir);
                    fflush(stdout);
                }
                else
                    valid = 0;
                break;
            }
            case CommandInput:
            {
                int len = strlen(argv[i + 1]);
                if (len)
                {
                    inputFile = malloc(len + 1);
                    //vcos_assert(inputFile);
                    if (inputFile)
                        strncpy(inputFile, argv[i + 1], len+1);
                    i++;
                    //ofile = fopen(directory, "wb");
                    //dfile = open(outputDir,  O_CREAT|O_WRONLY, S_IRUSR|S_IWUSR);
                    //dumfile = fopen("/home/pi/dum.data", "wb");
                    fprintf(stdout, "Input file given %s\n", inputFile);
                    fflush(stdout);

                }
                else
                    valid = 0;
                break;
            }

            case CommandWidth:
            {
                if (sscanf(argv[i + 1], "%u", &width) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "Width %d\n", width);
                fflush(stdout);
                break;
            }
            case CommandHeight:
            {
                if (sscanf(argv[i + 1], "%u", &height) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "Height %d\n", height);
                fflush(stdout);
                break;
            }
            case CommandInputFormat:
            {
                char * format;
                int len = strlen(argv[i + 1]);
                if (len)
                {
                    format = malloc(len + 1);
                    //vcos_assert(inputFile);
                    if (format)
                        strncpy(format, argv[i + 1], len+1);
                    i++;
                    fprintf(stdout, "Input format given %s\n", format);
                    if(strcmp(format,"RAW8") == 0)
                        inputFormat = INPUT_FORMAT_RAW8;
                    else if(strcmp(format,"RAW10") == 0)
                        inputFormat = INPUT_FORMAT_RAW10;
                    else {
                        fprintf(stdout, "Input format is not supported!\n");
                        valid = 0;
                    }
                    //ofile = fopen(directory, "wb");
                    //dfile = open(outputDir,  O_CREAT|O_WRONLY, S_IRUSR|S_IWUSR);
                    //dumfile = fopen("/home/pi/dum.data", "wb");
                    fflush(stdout);
                    free(format);

                }
                else
                    valid = 0;
                break;
            }
            case CommandInternalBpCh:
            {
                if (sscanf(argv[i + 1], "%u", &internalBpCh) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "internalBpCh %d\n", internalBpCh);
                fflush(stdout);
                break;
            }
            case CommandBrightness:
            {
                if (sscanf(argv[i + 1], "%u", &brightnes) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "Brightnes %d\n", brightnes);
                fflush(stdout);
                break;
            }
            case CommandContrast:
            {
                if (sscanf(argv[i + 1], "%u", &contrast) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "Contrast %d\n", contrast);
                fflush(stdout);
                break;
            }
            case CommandBalanceR:
            {
                if (sscanf(argv[i + 1], "%u", &balanceR) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "balanceR %d\n", balanceR);
                fflush(stdout);
                break;
            }
            case CommandBalanceG:
            {
                if (sscanf(argv[i + 1], "%u", &balanceG) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "balanceG %d\n", balanceG);
                fflush(stdout);
                break;
            }
            case CommandBalanceB:
            {
                if (sscanf(argv[i + 1], "%u", &balanceB) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "balanceB %d\n", balanceB);
                fflush(stdout);
                break;
            }
            case CommandExposure:
            {
                if (sscanf(argv[i + 1], "%u", &exposure) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "exposure %d\n", exposure);
                fflush(stdout);
                break;
            }
            case CommandGamma:
            {
                if (sscanf(argv[i + 1], "%f", &gammaVal) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "gammaVal %f\n", gammaVal);
                fflush(stdout);
                break;
            }
            case CommandHistogramMin:
            {
                if (sscanf(argv[i + 1], "%u", &histogramMin) != 1)
                    valid = 0;
                else
                    i++;
                doHistogramMap =1;
                fprintf(stdout, "histogramMin %d\n", histogramMin);
                fflush(stdout);
                break;
            }
            case CommandHistogramMax:
            {
                if (sscanf(argv[i + 1], "%u", &histogramMax) != 1)
                    valid = 0;
                else
                    i++;
                doHistogramMap = 1;
                fprintf(stdout, "histogramMax %d\n", histogramMax);
                fflush(stdout);
                break;
            }

            case CommandAWB_METHOD:
            {
                if (sscanf(argv[i + 1], "%u", &awb) != 1)
                    valid = 0;
                else
                    i++;
                fprintf(stdout, "AWB mode %d\n", awb);
                fflush(stdout);
                break;
            }

            case Command_Denoise_bayer_ON:
            {
                int tmp = 0;
                if (sscanf(argv[i + 1], "%u", &tmp) != 1)
                    valid = 0;
                else
                    i++;
                if(tmp != 0)
                    dnz_bayer = true;
                fprintf(stdout, "Denoise bayer %s\n", dnz_bayer ? "true" : "false" );
                fflush(stdout);
                break;
            }

            case Command_Denoise_RGB_ON:
            {
                int tmp = 0;
                if (sscanf(argv[i + 1], "%u", &tmp) != 1)
                    valid = 0;
                else
                    i++;
                if(tmp != 0)
                    dnz_rgb = true;
                fprintf(stdout, "Denoise RGB %s\n", dnz_rgb ? "true" : "false" );
                fflush(stdout);
                break;
            }

            case Command_SHARP_ON:
            {
                int tmp = 0;
                if (sscanf(argv[i + 1], "%u", &tmp) != 1)
                    valid = 0;
                else
                    i++;
                if(tmp != 0)
                    sharp = true;
                fprintf(stdout, "Sharpeping %s\n", sharp ? "true" : "false" );
                fflush(stdout);
                break;
            }
        }

        if (!valid)
        {
            fprintf(stderr, "Invalid command line option (%s)\n", argv[i-1]);
            return 1;
        }
    }
    return 0;
}
/**
 * Display usage information for the application to stdout
 *
 * @param app_name String to display as the application name
 */
static void display_valid_parameters(char *app_name)
{
   fprintf(stderr, "Converts raw debayer data to RGB and store results as ppm\n\n");
   fprintf(stderr, "\nusage: %s [options]\n\n", app_name);

   fprintf(stderr, "Image parameter commands\n\n");

   raspicli_display_help(cmdline_commands, cmdline_commands_size);

   fprintf(stderr, "\n");

   // Help for preview options
   ///raspipreview_display_help();

   // Now display any help information from the camcontrol code
   //raspicamcontrol_display_help();

   fprintf(stderr, "\n");

   return;
}

void cpyBuffer8Bit(char * dst,char * src, int len)
{
    //fprintf(stdout, "cpyBuffer %i len<<<\n", len);
    int index = 0;
    int srcIndex = 0;
    //uint64_t beforetime = vcos_getmicrosecs64()/1000;
    for(index = 0 ; index < len ; index+=5)
    {
        //fprintf(stdout, "cpyBuffer index %i\n", index);
        memcpy(&dst[srcIndex], &src[index], 4);
        srcIndex+=4;
    }
    //uint64_t aftertime = vcos_getmicrosecs64()/1000;
    //fprintf(stdout, "cpyBuffer took %lld>>> \n", (aftertime-beforetime));
}

void cpyBuffer16Bit(char * dst,char * src, int len)
{
    //fprintf(stdout, "cpyBuffer %i len<<<\n", len);
    int index = 0;
    int srcIndex = 0;
    //uint64_t beforetime = vcos_getmicrosecs64()/1000;
    for(index = 0 ; index < len ; index+=5)
    {
        //fprintf(stdout, "cpyBuffer index %i\n", index);
        memcpy(&dst[srcIndex],   &src[index], 1);
        memcpy(&dst[srcIndex+2], &src[index+1], 1);
        memcpy(&dst[srcIndex+4], &src[index+2], 1);
        memcpy(&dst[srcIndex+6], &src[index+3], 1);

        dst[srcIndex+1]=((src[index+4]&0xC0));
        dst[srcIndex+3]=((src[index+4]&0x30)<<2)&0xC0;
        dst[srcIndex+5]=((src[index+4]&0x0C)<<4)&0xC0;
        dst[srcIndex+7]=((src[index+4]&0x03)<<6)&0xC0;
        /*if(index > (1920*500) && index < (1920*600))
        {
            printf("%x \n", src[index+4] );
            printf("%x ", dst[srcIndex+1] );
            printf("%x ", dst[srcIndex+3] );
            printf("%x ", dst[srcIndex+5] );
            printf("%x \n", dst[srcIndex+7 ] );
        }
        */
        srcIndex+=8;
    }
    //uint64_t aftertime = vcos_getmicrosecs64()/1000;
    //fprintf(stdout, "cpyBuffer took %lld>>> \n", (aftertime-beforetime));
}

static void _mkdir(const char *dir) {
        char tmp[256];
        char *p = NULL;
        size_t len;

        snprintf(tmp, sizeof(tmp),"%s",dir);
        len = strlen(tmp);
        if(tmp[len - 1] == '/')
                tmp[len - 1] = 0;
        for(p = tmp + 1; *p; p++)
                if(*p == '/') {
                        *p = 0;
                        if(!strstr(tmp,"."))
                            mkdir(tmp, S_IRWXO);
                        *p = '/';
                }
        if(!strstr(tmp,"."))
            mkdir(tmp, S_IRWXO);
}

int main (int argc, const char **argv)
{
	fprintf(stderr, "\n%s APP %s\n\n", basename(argv[0]), VERSION_STRING);
    if (argc == 1)
    {
       //fprintf(stderr, "\n%s Debayer APP %s\n\n", basename(argv[0]), VERSION_STRING);

       display_valid_parameters(basename(argv[0]));
       exit(1);
    }

    if(parse_cmdline(argc, argv))
        exit(1);

    char filename[50];
    int fileCount=1;

    FILE * in;
    in = fopen(inputFile, "rb");
    if(!in){
        fprintf(stderr, "\nError opening input file: %s\n\n", inputFile);
    }
    //get the file size
    fseek(in, 0L, SEEK_END);
    int fileSize = ftell(in);
    fseek(in, 0L, SEEK_SET);

    int inSize = width*height;
    if(inputFormat == INPUT_FORMAT_RAW10 )
        inSize = width*height + width*height/4; //raw data contains 10 bit for color  RGRGrgrg
    unsigned char* inBuffer = malloc(inSize);
    unsigned char* tmp8BitBuffer;// = malloc(width*height);
    unsigned char* tmp16BitBuffer;// = malloc(width*height*2);
    if(internalBpCh == 8) {
        tmp8BitBuffer = malloc(width*height);
    } else
    {
        tmp16BitBuffer = malloc(width*height*2);
    }
    unsigned char* buffer;
    int channels = 3;
    int outSize = width*height*channels;
    unsigned char * outRGB = malloc(outSize);
    unsigned char * step1Buff = malloc(outSize);
    unsigned char * outFilters = malloc(outSize);
    demosaic_t debObj = demosaic_init(width,height, brightnes, contrast);
    //int tttsize = fread(inBuffer, 1,  inSize, in);
    //fprintf(stdout, "Read %d\n", tttsize);
    //fprintf(stdout, "Size %d\n", fileSize);
    while(fread(inBuffer, 1, inSize, in) == inSize) {
        buffer = inBuffer;
        if(inputFormat == INPUT_FORMAT_RAW10) {
            if(internalBpCh == 8)
            {
                cpyBuffer8Bit(tmp8BitBuffer, inBuffer, inSize);
                buffer = tmp8BitBuffer;
            } else if(internalBpCh=10)
            {
                cpyBuffer16Bit(tmp16BitBuffer, inBuffer, inSize);
                buffer = tmp16BitBuffer;
            }
        }

        //whitePatch(buffer, width, inSize);
        long start = vcos_getmicrosecs64()/1000;
        //sensorRGB2sRGBspace(buffer,width,inSize);
        //grayWorld(buffer, width, inSize);
        //awbColorWeights(buffer, width, inSize);
        //whitePatch(buffer, width, inSize);
        debayer_process(debObj, buffer,  outRGB, (float) brightnes/255, (float) contrast/255, (float)balanceR/255, (float)balanceG/255, (float)balanceB/255, (float) exposure, gammaVal, (float) histogramMin/255, (float) histogramMax/255, internalBpCh, awb, dnz_bayer, dnz_rgb, sharp);
        long end = vcos_getmicrosecs64()/1000;
        printf("Debayer took:%d\n", (end - start));
        /*
        demosaic_process(debObj, buffer,  outRGB);
        //initColorWeights(outRGB, outSize);
        demosaic_process_filters_step1(debObj, outRGB, step1Buff, weightRed, weightGreen, weightBlue,  (float)balanceR,  (float)balanceG/255,  (float)balanceB/255, (float) exposure, gammaVal);
        calculateHistogramMap(step1Buff);
        demosaic_process_filters_step2(debObj, step1Buff,  outFilters, (float) brightnes/255, (float) contrast/255, (float) histogramMin/255, (float) histogramMax/255);
        */
        FILE * out;
        if(outputFile)
            sprintf(filename, "%s", outputFile);
        else
            if(outputDir )
                sprintf(filename, "%s%d.ppm",outputDir, fileCount);
            else
                sprintf(filename, "debayer%d.ppm",fileCount);
        if(outputDir)
            _mkdir(outputDir);
        else
            _mkdir(filename);
        out = fopen(filename, "wb");
        if(out < 0) {
            perror("open");
            return -1;
        }
        fprintf(out, "P6\n%d %d\n255\n", width, height);
        if(fwrite(outRGB, 1, outSize, out) != outSize)
        {
            printf("Wrong at writing\n");
        }
        fclose(out);

		
		if(DEBUG && outputDir )
		{
            sprintf(filename, "%s%d.raw",outputDir, fileCount);
			out = fopen(filename, "wb");
			if(out < 0) {
				perror("open");
				return -1;
			}
			//fprintf(out, "P6\n%d %d\n255\n", width, height);
			if(fwrite(buffer, 1, width*height, out) != width*height)
			{
				printf("Wrong at writing\n");
			}
			fclose(out);
		}
        /*
        if(outputDir)
            sprintf(filename, "%sdebayer%d_nonfiltered.ppm", outputDir, fileCount);
        else

            sprintf(filename, "debayer%d_nonfiltered.ppm",fileCount);
        out = fopen(filename, "wb");
        if(out < 0) {
            perror("open");
            return -1;
        }
        fprintf(out, "P6\n%d %d\n255\n", width, height);
        if(fwrite(outRGB, 1, outSize, out) != outSize)
        {
            printf("Wrong at writing\n");
        }
        fclose(out);
*/
        fileCount++;
    }
    if(PROGRESS) fprintf(stdout,"Done\n");
    fclose(in);
    demosaic_destroy(debObj);
    free(buffer);
    free(step1Buff);
    free(outRGB);
    free(outFilters);
    free(inBuffer);
    free(inputFile);
    free(outputDir);

    return 0;
}
